# TrelloDemoApp
TrelloDemoApp for UBB

In order for the tests to run, you need to set the Trello USERNAME, PASSWORD, user KEY, and user TOKEN here: https://github.com/cosminevo/TrelloDemoApp/blob/master/src/test/resources/testdata/data.csv
